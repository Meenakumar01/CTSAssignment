Application has two options.
1. Display
2. Report

Display: Only UI functionalities(excluding minimal count)
Report : UI along with Java

Both:
After selecting the file once we click upload.

List of records in the file gets displayed.

For Report option, we can validate the records by clicking "Validate" button.

List of Errors will be displayed at the bottom.