package com.websystique.springmvc.service;
import com.websystique.springmvc.model.Reports;

public interface ValidationService {
	
	Reports validate(Reports records); 
	
}
